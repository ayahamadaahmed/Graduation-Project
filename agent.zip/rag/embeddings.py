from __future__ import annotations

import os

from functools import lru_cache

import numpy as np

from sentence_transformers import (
    SentenceTransformer,
)


MODEL_NAME = (
    "BAAI/bge-m3"
)

EMBEDDING_DEVICE = (
    os.getenv(
        "RAG_EMBEDDING_DEVICE",
        "cpu",
    )
    .strip()
    .lower()
)


@lru_cache(
    maxsize=1
)
def get_embedding_model() -> SentenceTransformer:

    return SentenceTransformer(
        MODEL_NAME,
        device=EMBEDDING_DEVICE,
    )


def embed_text(
    text: str,
) -> np.ndarray:

    model = (
        get_embedding_model()
    )

    vector = (
        model.encode(
            text,
            normalize_embeddings=True,
        )
    )

    return vector


def embed_texts(
    texts: list[str],
) -> np.ndarray:

    model = (
        get_embedding_model()
    )

    vectors = (
        model.encode(
            texts,
            normalize_embeddings=True,
        )
    )

    return vectors